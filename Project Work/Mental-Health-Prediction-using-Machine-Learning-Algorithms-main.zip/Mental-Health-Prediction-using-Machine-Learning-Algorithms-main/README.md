# Mental-Health-Prediction-using-Machine-Learning-Algorithms
Prediction of Mental Health using various Machine Learning Algorithms and made a Web page which will predict the probability of Mental illness based on inputs provided by user.
